plugins {
    id("com.android.application")
}

android {
    namespace = "com.sscprep.maths"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sscprep.maths"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
